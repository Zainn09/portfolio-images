# Prime Baby Gear — QA Portfolio Visual Assets

**Project:** Prime Baby Gear  
**Website URL:** https://primebabygear.com  
**Project type:** UK retailer of premium baby gear: prams, travel systems, car seats, nursery furniture, and accessories  
**Asset-generation date:** 2026-09-20

## Inventory

- Static images: **13**
- Videos: **1**
- Video thumbnails: **1** (stored with the video)

## Coverage

- `95_prime_baby_gear_desktop_home_hero_001.jpg` — Desktop homepage hero
- `95_prime_baby_gear_desktop_collection_listing_001.jpg` — Desktop listing / catalogue
- `95_prime_baby_gear_desktop_travel_system_detail_001.jpg` — Desktop detail page
- `95_prime_baby_gear_project_highlight_mercedes_signature_travel_system_collection_001.jpg` — Project highlight: Mercedes signature travel-system collection
- `95_prime_baby_gear_desktop_secondary_experience_001.jpg` — Secondary project-specific experience
- `95_prime_baby_gear_desktop_babymore_brand_range_001.jpg` — Babymore brand range
- `95_prime_baby_gear_desktop_baby_jogger_range_001.jpg` — Baby Jogger brand range
- `95_prime_baby_gear_mobile_home_hero_001.jpg` — Mobile homepage hero
- `95_prime_baby_gear_interaction_mobile_navigation_001.jpg` — Mobile navigation state
- `95_prime_baby_gear_mobile_travel_system_detail_001.jpg` — Mobile detail page
- `95_prime_baby_gear_mobile_project_specific_section_001.jpg` — Mobile project-specific section
- `95_prime_baby_gear_responsive_comparison_001.jpg` — Desktop / mobile responsive QA comparison
- `95_prime_baby_gear_qa_user_flow_sequence_001.jpg` — Three-state QA user-flow reference

## Video

- `95_prime_baby_gear_video_baby_gear_journey_001.mp4` — Premium baby-gear discovery from best sellers to travel-system detail
- `95_prime_baby_gear_video_baby_gear_journey_001.jpg` — Video poster / thumbnail

## Capture notes

- Captures use the live website as the source of truth; no products, copy, testimonials, UI states, or defects were fabricated.
- Desktop viewport: 1440 × 900; mobile viewport: 390 × 844; video: 1280 × 720.
- Responsive and user-flow compositions contain only authentic live-site captures plus neutral QA reference labels.
- No checkout submission, purchase, account creation, or personal data entry was performed.
- The live sitemap endpoints did not return route data; configured routes were captured directly.
- Playable MP4 verified: H.264, 1280×720, 29.96 seconds, complete decode passed.
- Rejected duplicate 95_prime_baby_gear_desktop_signature_section_001.jpg; it matched 95_prime_baby_gear_desktop_home_hero_001.jpg byte-for-byte.
- Rejected duplicate 95_prime_baby_gear_interaction_detail_state_001.jpg; it matched 95_prime_baby_gear_desktop_travel_system_detail_001.jpg byte-for-byte.
